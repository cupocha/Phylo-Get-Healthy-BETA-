# Limitations

PhyloGetHealthy provides evidence-based estimates but is subject to the following constraints:

1. **Population-Level Guidance:** Not individualized clinical prescriptions.
2. **Medical Exclusions:** Does not account for acute illness, chronic disease, or pharmacological interactions.
3. **Nutritional Guidance:** General recommendations only; allergies, restrictions, or specific diets are not considered.
4. **Circadian Assumptions:** Sleep and performance logic assumes standard diurnal schedules; irregular patterns reduce accuracy.
5. **Exercise Guidance:** High-intensity recommendations assume baseline health; consult professionals for medical clearance.
6. **Data Reliability:** Missing inputs (e.g., waist circumference) reduce confidence scores.
