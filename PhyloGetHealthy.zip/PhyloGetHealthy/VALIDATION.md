# Validation

PhyloGetHealthy outputs are validated against established scientific guidelines:

- **BMR & TDEE:** Verified with Mifflin-St Jeor equations.
- **BMI & Waist-to-Height Ratios:** Checked against peer-reviewed research for accuracy.
- **Exercise Logic:** Cross-referenced with ACSM guidelines for frequency, intensity, and recovery periods.
- **Safety Overrides:** Extreme-case testing ensures recommendations respond appropriately to high fatigue, low sleep, or abnormal BMI.
- **Consistency:** System notes and professional view data verified for logical coherence with source literature.
