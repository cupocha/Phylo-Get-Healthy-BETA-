# How to Use PhyloGetHealthy

PhyloGetHealthy consists of two integrated applications: **PhyloHealth** and **PhyloWork**.

## Launch Instructions
1. Open the `PhyloGetHealthy` folder.
2. Select one of the apps:
   - `phylohealth/index.html` → Clinical metabolic and lifestyle analysis.
   - `phylowork/index.html` → Workout planning and physical guidance.

## User Input
- Provide core metrics:
  - Height, Weight, Age, Sex
  - Fatigue level, Sleep quality, Activity frequency and intensity
- Optional: Waist circumference for advanced reliability scoring.

## Executing Analysis
- Click **Execute Architecture Analysis** (PhyloHealth) or **Generate Plan** (PhyloWork) to receive guidance.
- Enable **Professional View** for detailed computational logic and decision metrics.

## Best Practices
- Input accurate and recent measurements.
- Use caution with “YOUR MAX” features in PhyloWork; they may indicate risk if misused.
- Consult professionals for any medical concerns or extreme metrics.
