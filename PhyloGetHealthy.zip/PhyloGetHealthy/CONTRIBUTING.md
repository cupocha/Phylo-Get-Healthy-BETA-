# Contributing to PhyloGetHealthy

We welcome contributions from developers, researchers, and health professionals.

## Guidelines
1. Fork the repository.
2. Create a branch for your changes.
3. Implement improvements or fixes.
4. Submit a Pull Request including:
   - A detailed description of your changes.
   - Scientific references for any new or updated calculations.
   - Screenshots or test results if applicable.
5. Follow existing code style and document logic changes clearly.

## Areas for Contribution
- Adding new health metrics or algorithms.
- Improving UI/UX or app accessibility.
- Extending professional view with deeper insights.
- Updating references to latest scientific literature.
